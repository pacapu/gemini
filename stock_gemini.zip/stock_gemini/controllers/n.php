b<?php
require_once 'includes/config.php';
require_once 'includes/db.php'; // Asegúrate de incluir db.php
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Obtener la conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

$auth = new Auth($db); // Pasar la conexión a la base de datos al constructor de Auth
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Obtener el almacén principal
$query = "SELECT * FROM warehouses WHERE is_main = 1 LIMIT 1";
$stmt = $db->prepare($query);
$stmt->execute();
$mainWarehouse = $stmt->fetch(PDO::FETCH_ASSOC);

// Obtener productos del almacén principal
$products = [];
if ($mainWarehouse) {
    $query = "SELECT p.* FROM products p WHERE p.warehouse_id = :warehouse_id ORDER BY p.inventory_number";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':warehouse_id', $mainWarehouse['id']);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Obtener subalmacenes
$subWarehouses = [];
if ($mainWarehouse) {
    $query = "SELECT * FROM warehouses WHERE parent_id = :parent_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':parent_id', $mainWarehouse['id']);
    $stmt->execute();
    $subWarehouses = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<h2>Dashboard</h2>

<div class="dashboard-container">
    <div class="quick-search">
        <form action="search.php" method="get">
            <input type="text" name="q" placeholder="Búsqueda rápida...">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <div class="main-warehouse">
        <h3>Almacén Principal: <?php echo htmlspecialchars($mainWarehouse['name']); ?></h3>
        
        <?php if (!empty($products)): ?>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>N° Inventario</th>
                        <th>N° Serie</th>
                        <th>Descripción</th>
                        <th>Cantidad</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['inventory_number']); ?></td>
                            <td><?php echo htmlspecialchars($product['serial_number']); ?></td>
                            <td><?php echo htmlspecialchars($product['description']); ?></td>
                            <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                            <td>
                                <a href="products.php?action=view&id=<?php echo $product['id']; ?>" class="btn-view"><i class="fas fa-eye"></i></a>
                                <a href="products.php?action=edit&id=<?php echo $product['id']; ?>" class="btn-edit"><i class="fas fa-edit"></i></a>
                                <a href="products.php?action=move&id=<?php echo $product['id']; ?>" class="btn-move"><i class="fas fa-exchange-alt"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay productos en el almacén principal.</p>
        <?php endif; ?>
    </div>

    <?php if (!empty($subWarehouses)): ?>
        <div class="sub-warehouses">
            <h3>Subalmacenes</h3>
            <div class="warehouse-grid">
                <?php foreach ($subWarehouses as $warehouse): ?>
                    <div class="warehouse-card">
                        <h4><?php echo htmlspecialchars($warehouse['name']); ?></h4>
                        <p><?php echo htmlspecialchars($warehouse['description']); ?></p>
                        <a href="warehouses.php?action=view&id=<?php echo $warehouse['id']; ?>" class="btn-view">Ver Detalles</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>