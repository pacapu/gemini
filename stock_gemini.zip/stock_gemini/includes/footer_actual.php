</main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Gemini Stock Control</p>
    </footer>
</body>
</html>